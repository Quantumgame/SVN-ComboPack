%%  Test C-STRAIGHT

startTic = tic;
!straight -q -tv 1004 -thfc -lf0 50 -uf0 300 qqqqqQ.wav qqqqqQSyn.wav
toc(startTic)
