function plotMarkerStyle = getPlotMarkerStyle()

plotMarkerStyle = '*';